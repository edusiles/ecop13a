#include "triangulo.h"

int main() {
	// Instanciação do objeto:
	Triangulo triangulo(2, 5, 2);

	// Testar e exibir as possibilidades:
	triangulo.allPossibilities();

	return 0;
}